# start_all.ps1

$logDir = "D:\GARVIS\logs"
if (!(Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir | Out-Null }

$logFile = Join-Path $logDir ("{0:yyyy-MM-dd_HH-mm-ss}_start.log" -f (Get-Date))

Start-Transcript -Path $logFile -Append

Write-Host ">> Starte gpu0 ..."
Start-Process -FilePath "ollama" -ArgumentList "serve --port 11434" -WindowStyle Hidden

Write-Host ">> Starte gpu1 ..."
Start-Process -FilePath "ollama" -ArgumentList "serve --port 11435" -WindowStyle Hidden

Write-Host ">> Starte cpu ..."
Start-Process -FilePath "ollama" -ArgumentList "serve --port 11436" -WindowStyle Hidden

Write-Host ">> Starte router ..."
Start-Process -FilePath "python" -ArgumentList "D:\GARVIS\router\main.py" -WindowStyle Hidden

Write-Host ">> Starte evaluator ..."
Start-Process -FilePath "python" -ArgumentList "D:\GARVIS\evaluator\main.py" -WindowStyle Hidden

# kurze Pause, dann Status prüfen
Start-Sleep -Seconds 5
$services = @(
  @{ Name="gpu0"; Port=11434 },
  @{ Name="gpu1"; Port=11435 },
  @{ Name="cpu";  Port=11436 },
  @{ Name="router"; Port=28100 },
  @{ Name="evaluator"; Port=11437 }
)

Write-Host "`n=== GARVIS Startup Summary ===`n"
$services | ForEach-Object {
  try {
    $r = Invoke-WebRequest -Uri "http://127.0.0.1:$($_.Port)/api/tags" -UseBasicParsing -TimeoutSec 2
    [PSCustomObject]@{ Name=$_.Name; Port=$_.Port; Status="OK" }
  } catch {
    [PSCustomObject]@{ Name=$_.Name; Port=$_.Port; Status="FAIL" }
  }
} | Format-Table -AutoSize

Stop-Transcript
